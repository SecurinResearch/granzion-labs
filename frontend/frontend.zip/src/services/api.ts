import axios from 'axios';

const api = axios.create({
    baseURL: '/api',
});

export const getAgents = async () => {
    const response = await api.get('/agents');
    return response.data;
};

export const getAgentCard = async (agentId: string) => {
    const response = await axios.get(`/a2a/agents/${agentId}/.well-known/agent-card.json`);
    return response.data;
};

export const getScenarios = async () => {
    const response = await api.get('/scenarios');
    return response.data;
};

export const getSystemHealth = async () => {
    const response = await api.get('/health');
    return response.data;
};

export const getLogs = async () => {
    const response = await api.get('/logs');
    return response.data;
};

export const getEvents = async () => {
    const response = await api.get('/events');
    return response.data;
};

export const runScenario = async (scenarioId: string) => {
    const response = await api.post(`/scenarios/${scenarioId}/run`);
    return response.data;
};

export const rotateAgentKey = async (agentId: string) => {
    const response = await api.post(`/agents/${agentId}/rotate-key`);
    return response.data;
};

export default api;
